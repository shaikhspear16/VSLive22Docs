﻿using System.Windows;

namespace UsingTask.UI;

public partial class App : Application
{
}

