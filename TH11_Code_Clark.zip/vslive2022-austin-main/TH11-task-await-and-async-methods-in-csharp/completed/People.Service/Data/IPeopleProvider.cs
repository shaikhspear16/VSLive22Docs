namespace People.Service;

public interface IPeopleProvider
{
    List<Person> GetPeople();
}

