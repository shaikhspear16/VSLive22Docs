﻿using System.Windows;

namespace delegates;

public partial class App : Application
{
}

