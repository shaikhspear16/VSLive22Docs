﻿namespace delegates;

//public static class Formatters
//{
//    public static string Default(Person person)
//    {
//        return person.ToString();
//    }

//    public static string FamilyNameToUpper(Person person)
//    {
//        return person.FamilyName.ToUpper();
//    }

//    public static string GivenNameToLower(Person person)
//    {
//        return person.GivenName.ToLower();
//    }

//    public static string FullName(Person person)
//    {
//        return $"{person.FamilyName}, {person.GivenName}";
//    }
//}
